<?php

// permet de nettoyer les données passées en param
function clean_data($data) {
    $data = trim($data); // Permet de retirer tout ce qui n'est pas une lettre ou un chiffre
    $data = stripslashes($data); // Permet de retirer les \ de $data
    $data = htmlspecialchars($data); // Transforme les charactères spéciaux en entité HTML
    return $data;
}