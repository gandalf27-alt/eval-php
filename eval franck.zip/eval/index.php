<?php
// Récupère les fichiers utils
require('inc/db.php');
require('inc/utils.php');




require('logement/logementControler.php');

include ('logement/listLogement.php');

if (empty($_GET['page'])) {
    // j'envois vers la page d'accueil
   showLogements();
} else { //Sinon
    // Récupère la page voulue depuis l'URL
    $page = $_GET['page'];



    if ($page == "logements") {
        // Demande d'afficher la liste des logements.
        showLogements();
        } else if ($page == "logement") {
        // Demande d'afficher un logement
        showLogement();
        } else if ($page == "addlogement") {
        // Demande d'afficher le formulaire d'ajout d'un logement
        showAddLogement();
        } else if ($page == "createlogement") {
        // Sauvegarde en BDD les infos du formulaire
        saveLogement();
        } else if ($page == "updatelogement") {
        // Demande à afficher le formulaire de modification d'un logement
        showUpdateLogement();
        } else if ($page == "editlogement") {
        // Demande à modifier un logement
        editLogement();
        } else if ($page == "deletelogement") {
        // Demande la suppression d'un clien
        deleteLogement();
    }
   
}

    require('logement/header.php');
   
   
