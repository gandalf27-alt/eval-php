<?php
$title = (isset($edit)?"modifier":"ajouter");
ob_start()
?>

<div class="row">
    <div class="col">
        <?php if (isset($edit)) { ?>
            <h1>Modifier un logement #<?= $logement['id'] ?></h1>
        <?php } else { ?>
            <h1>Ajouter un logement</h1>
        <?php }?>
    </div>
</div>
<div class="row">
    <div class="col">
        
        <form action="index.php?page=<?= (isset($edit)?"editlogement&id=".$logement['id']:"createlogement") ?>" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="titre">titre</label>
                <input type="text" class="form-control <?= (!empty($errors['titre']))? "is-invalid" : "" ?>" name="titre"  id="titre" aria-describedby="lastnameHelp" value="<?= (!empty($logement))? $logement['titre'] : "" ?>">
                <?php if(!empty($errors['titre'])) { ?>
                    <div class="invalid-feedback"><?= $errors['titre'] ?></div>
                <?php } ?>
                <small id="lastnameHelp" class="form-text text-muted">titre de l'annonce</small>
            </div>

            <div class="form-group">
                <label for="adresse">Adresse</label>
                <input type="text" class="form-control <?= (!empty($errors['adresse']))? "is-invalid" : "" ?>" name="adresse" required id="adresse" aria-describedby="lastnameHelp" value="<?= (!empty($logement))? $logement['adresse'] : "" ?>">
                <?php if(!empty($errors['adresse'])) { ?>
                    <div class="invalid-feedback"><?= $errors['adresse'] ?></div>
                <?php } ?>
                <small id="lastnameHelp" class="form-text text-muted">Adresse du bien</small>
            </div>

            <div class="form-group">
                <label for="ville">Ville</label>
                <input type="text" class="form-control <?= (!empty($errors['ville']))? "is-invalid" : "" ?>" name="ville" required id="price" aria-describedby="lastnameHelp" value="<?= (!empty($logement))? $logement['ville'] : "" ?>">
                <?php if(!empty($errors['ville'])) { ?>
                    <div class="invalid-feedback"><?= $errors['ville'] ?></div>
                <?php } ?>
                <small id="lastnameHelp" class="form-text text-muted">Ville</small>
            </div>

            <div class="form-group">
                <label for="cp">Code Postal</label>
                <input type="number" class="form-control <?= (!empty($errors['cp']))? "is-invalid" : "" ?>" name="cp" required id="cp" aria-describedby="lastnameHelp" value="<?= (!empty($logement))? $logement['cp'] : "" ?>">
                <?php if(!empty($errors['cp'])) { ?>
                    <div class="invalid-feedback"><?= $errors['cp'] ?></div>
                <?php } ?>
                <small id="lastnameHelp" class="form-text text-muted">Code Postal</small>
            </div>

            <div class="form-group">
                <label for="surface">Surface</label>
                <input type="number" class="form-control <?= (!empty($errors['surface']))? "is-invalid" : "" ?>" name="surface" required id="surface" aria-describedby="lastnameHelp" value="<?= (!empty($logement))? $logement['surface'] : "" ?>">
                <?php if(!empty($errors['surface'])) { ?>
                    <div class="invalid-feedback"><?= $errors['surface'] ?></div>
                <?php } ?>
                <small id="lastnameHelp" class="form-text text-muted">Surface</small>
            </div>

            <div class="form-group">
                <label for="prix">Prix</label>
                <input type="number" class="form-control <?= (!empty($errors['prix']))? "is-invalid" : "" ?>" name="prix" required id="prix" aria-describedby="lastnameHelp" value="<?= (!empty($logement))? $logement['prix'] : "" ?>">
                <?php if(!empty($errors['prix'])) { ?>
                    <div class="invalid-feedback"><?= $errors['prix'] ?></div>
                <?php } ?>
                <small id="lastnameHelp" class="form-text text-muted">Prix</small>
            </div>

            <div class="form-group">
                <label for="type">type</label>
                <select class="form-control <?= (!empty($errors['type']))? "is-invalid" : "" ?>" required name="type" >
                    <option value="location">Location</option>
                    <option value="vente">Vente</option>
                    
                </select>
                <?php if(!empty($errors['type'])) { ?>
                    <div class="invalid-feedback"><?= $errors['type'] ?></div>
                <?php } ?>
                <small id="lastnameHelp" class="form-text text-muted">Photo du Bien</small>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control <?= (!empty($errors['description']))? "is-invalid" : "" ?>" rows="3" name="description"><?= (!empty($equipement))? $equipement['description'] : "" ?></textarea>
                <?php if(!empty($errors['description'])) { ?>
                    <div class="invalid-feedback"><?= $errors['description'] ?></div>
                <?php } ?>
                <small id="lastnameHelp" class="form-text text-muted">Description du bien</small>
            </div>    
            <button type="submit" class="btn btn-primary">Sauvegarder</button>
        </form>
    </div>
</div>

<?php
$content = ob_get_clean();
require('template.php');