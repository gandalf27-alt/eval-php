<?php
$title = "Liste des Logements"; // on donne le nom de notre page.
$logements = getLogements();
ob_start(); // On démarre "l'enregistrement" du HTML
?>
<div class="row">
    <div class="col d-flex justify-content-between align-items-center">
        <h1>Liste des logements</h1>
        <a class="btn btn-primary btn-sm" href="index.php?page=add">ajouter</a>
    </div>
</div>
<div class="row">
    <div class="col">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Titre</th>
                    <th>Adresse</th>
                    <th>Ville</th>
                    <th>Code postal</th>
                    <th>Surface</th>
                    <th>Prix</th>
                    <th>Photo</th>
                    <th>Type</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                // Boucle sur chaque élément de notre tableau 
                foreach($logements as $logement) {
                ?>
                <tr>
                    <td><?= $logement['id'] ?></td>
                    <td><?= $logement['titre'] ?></td>
                    <td><?= $logement['adresse'] ?></td>
                    <td><?= $logement['ville'] ?></td>
                    <td><?= $logement['cp'] ?></td>
                    <td><?= $logement['surface'] ?></td>
                    <td><?= $logement['prix'] ?></td>
                    <td><?= $logement['photo'] ?></td>
                    <td><?= $logement['type'] ?></td>
                    <td><?= $logement['description'] ?></td>
                    <td>
                        <a class="btn btn-success btn-sm" href="index.php?page=showlogement&id=<?= $logement['id'] ?>">Voir</a>
                        <a class="btn btn-warning btn-sm" href="index.php?page=updatelogement&id=<?= $logement['id'] ?>">Modifier</a>
                        <button class="btn btn-danger btn-sm delete" data-id="<?= $logement['id'] ?>">Supprimer</button>
                    </td>
                </tr>
                <?php    
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    // On récup le bouton de suppression et on l'écoute
    var btnsDelete = document.getElementsByClassName('delete'); // on récup tous les boutons
    for (i = 0; i < btnsDelete.length; i++) {
        // pour chaque bouton on va écouter l'évènement click
        btnsDelete[i].addEventListener('click', function() {
            // On demande si l'utilisateur veut vraiement supprimer le technicien
            if(confirm("Voulez-vous supprimer ce logement ?")) {
                // Si oui, on redirige vers la page de suppression.
                // this.dataset.id permet de récupérer la valeur de l'attribut data-id sur l'HTML du bouton
                window.location.replace(`index.php?page=deletelogement&id=${this.dataset.id}`)
            }
        })
    }
</script>
<?php
$content = ob_get_clean(); // On stop "l'enregistrement" du HTML et on le "sauvegarde" dans la variable content

require('template.php'); // on appel notre template, $title et $content du template vont être remplacer par les valeurs définies plus haut