<?php
/**
 * logement controler
 */


require('modelLogement.php');

// Show all equipment
function showLogements() {
    //$logements = getLogements();
    include('listLogement.php');
}

// Show an equipment
function showLogement() {
    // Récup l'logement
    $logement = getLogement(clean_data($_GET['id']));
    include('showLogement.php');
}

// Show add logement page
function showAddLogement() {
    include('add.php');
}

// Add a new logement
function addLogement() {
    // Récupère les données valides
    $datas = getValidatedLogement();
    // Upload de la photo
    // Test si on a une photo et que l'upload n'est pas en erreur
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        // on bouge le fichier du répertoire temp vers notre dossier images
        $nomPhoto = time()."-".basename($_FILES['photo']['name']);
        move_uploaded_file($_FILES['photo']['tmp_name'], 'public/images/'.$nomPhoto);
        // On enregistre le nom de notre photo en BDD
        $datas['photo'] = $nomPhoto;
    }

    // Envois au Model pour ajout en BDD
    $newLogId = createLogement($datas);
    // Renvois vers la fiche du logement
    header('Location: index.php?page=showLogement&id='.$newLogId);
}

// Update an logement
function showUpdateLogement() {
    $logement = getLogement(clean_data($_GET['id']));
    $edit = true;
    include('add.php');
}

// Edit an logement
function editLogement() {
    $id = clean_data($_GET['id']);
    $datas = getValidatedLogement();
    updatelogement($datas, $id);
    header('Location: index.php?page=showLogement&id='.$id);
}

// Delete an logement
function deleteLogement() {
    $id = clean_data($_GET['id']);
    destroyLogement($id);
    header('Location: index.php?page=logements');
}

function getValidatedLogement() {
    $errors = array();

    if (empty($_POST['titre'])) {
        $errors['titre'] = "Champ requis";
    }
    if (empty($_POST['adresse'])) {
        $errors['adresse'] = "Champ requis";
    }
    if (empty($_POST['ville'])) {
        $errors['ville'] = "Champ requis";
    }
    if (!is_int((int)$_POST['cp'])) {
        $errors['cp'] = "Doit être un nombre";
    }
    if (!is_int((int)$_POST['surface'])) {
        $errors['surface'] = "Doit être un nombre";
    }
    //if (!is_int((int)$_POST['price'])) {
       // $errors['surface'] = "Doit être un nombre";
    //}
    if (empty($_POST['type'])) {
        $errors['type'] = "Champ requis";
    }
    if (array_search($_POST['type'], ['location', 'vente',]) === false) {
        $errors['type'] = "Le champ ne peut contenir que Location ou Vente";
    }

    if (empty($errors)) {
        return array(
            "titre" => clean_data($_POST['titre']),
            "adresse" => clean_data($_POST['adresse']),
            "ville" => clean_data((int)$_POST['ville']),
            "cp" => clean_data($_POST['cp']),
            "surface" => clean_data($_POST['surface']),
            "prix" => clean_data($_POST['prix']),
            "type" => clean_data($_POST['type']),
            "description" => clean_data($_POST['description'])
        );
    } else {
        $logement = array(
            "titre" => $_POST['titre'],
            "adresse" =>$_POST['adresse'],
            "ville" => $_POST['ville'],
            "cp" => $_POST['cp'],
            "surface" => $_POST['surface'],
            "prix" => $_POST['prix'],
            "type" => $_POST['type'],
            "description" =>$_POST['description']

        );
        include('add.php');
        die();
    }
}