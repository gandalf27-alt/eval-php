<?php

// récup tous les logements
function getLogements() {
    $db = getDB();
    $request = $db->prepare('SELECT * FROM logement');
    $request->execute();

    return $request->fetchAll(); 
}

// Récup un seul logement
function getLogement($id) {
    $db = getDB();
    $request = $db->prepare('SELECT * FROM logement WHERE id = :id');
    $request->bindParam(":id", $id);
    $request->execute();

    return $request->fetch();
}

// Fonction d'ajout d'un logement
function createLogement($newlog) {
    // on récup la DB
    $db = getDB();
    // On prépare notre requête d'ajout
    $req = $db->prepare('INSERT INTO logement (titre, adresse, ville, cp, surface, prix, type, description) VALUES (:titre, :adresse, :ville, :cp, :surface, :prix, :type, :description)');
    // On bind les paramètres
    $req->bindParam(":titre", $newlog['titre']);
    $req->bindParam(":adresse", $newlog['adresse']);
    $req->bindParam(":ville", $newlog['ville']);
    $req->bindParam(":cp", $newlog['cp']);
    $req->bindParam(":cp", $newlog['surface']);
    $req->bindParam(":cp", $newlog['prix']);
    $req->bindParam(":type", $newlog['type']);
    $req->bindParam(":description", $newlog['description']);
    // On execute la requete
    $req->execute();
    // on récup et retourne l'ID du nouveau logement
    return $db->lastInsertId();
}

function updateLogement($logement, $id) {
    // on récup la DB
    $db = getDB();
    // On prépare notre requête d'ajout
    $req = $db->prepare('UPDATE logement SET titre = :titre, adresse = :adresse, ville = :ville, cp = :cp, surface = :surface, prix = :prix type = :type, description = :description WHERE id = :id');
    // On bind les paramètres
    $req->bindParam(":id", $id);
    $req->bindParam(":titre", $logement['titre']);
    $req->bindParam(":adresse", $logement['adresse']);
    $req->bindParam(":ville", $logement['ville']);
    $req->bindParam(":cp", $logement['cp']);
    $req->bindParam(":cp", $logement['surface']);
    $req->bindParam(":cp", $logement['prix']);
    $req->bindParam(":type", $logement['type']);
    $req->bindParam(":description", $logement['description']);
    // on execute
    $req->execute();

    return;
}

// delete logement
function destroyLogement($id) {
    // on récup la DB
    $db = getDB();
    // On prépare notre requête d'ajout
    $req = $db->prepare('DELETE FROM logement WHERE id = :id');
    // On bind les paramètres
    $req->bindParam(":id", $id);
    // on execute
    $req->execute();

    return;
}